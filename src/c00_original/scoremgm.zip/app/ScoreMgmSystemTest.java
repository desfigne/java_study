package com.scoremgm.app;

public class ScoreMgmSystemTest {

	public static void main(String[] args) {
		new ScoreMgmSystem();

	}

}
